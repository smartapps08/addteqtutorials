package com.myorg.picker;

public interface Interface1 {
	void interface1();

}
