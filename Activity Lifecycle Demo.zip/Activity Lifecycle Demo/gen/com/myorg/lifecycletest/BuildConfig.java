/** Automatically generated file. DO NOT MODIFY */
package com.myorg.lifecycletest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}